from gurobipy import *

def solve(N, M, k, A, r_sum):
    blocks = range(1,k+1)

    # Modell initialisieren
    model = Model("staircasedetection")
    model.modelSense = GRB.MINIMIZE

    # Variablen initialisieren
    x,y,z = {}, {}, {}
    for b in blocks:
       for j in N:
           x[j,b] = model.addVar(name=f"x_{j}_{b}", vtype=GRB.BINARY)
       for i in M:
           y[i,b] = model.addVar(name=f"y_{i}_{b}", vtype=GRB.BINARY)
    for j in N:
        z[j] = model.addVar(name=f"z_{j}", vtype=GRB.BINARY)

    model.setObjective(quicksum(z[j] for j in N))
    model.update()

    # var i in genau einem Block oder in zwei, wenn linking (z_i = 1)
    for j in N:
        for b in range(1, k):
            model.addConstr(x[j,b] + x[j,b+1] <= 1 + z[j])
    
    # var i taucht nur in aufeinanderfolgenden Blöcken auf
    for j in N:
        for b in range(1, k-1):
            for l in range(2, k+1-b):
                model.addConstr(x[j,b] + x[j,b+l] <= 1)

    # jede constraint ist genau einem Block zugeordnet
    for i in M:
        model.addConstr(quicksum(y[i,b] for b in blocks) == 1)
    
    # jeder Block hat mindestens eine constraint
    for b in blocks:
        model.addConstr(quicksum(y[i,b] for i in M) >= 1)

    # für jede constraint existieren die vars in dem zugewiesenen Block
    for b in blocks:
        for i in M:
            model.addConstr(quicksum((A[i-1,j-1]*x[j,b]) for j in N) >= r_sum[i-1]*y[i,b])

    model.optimize()

    # Ausgabe der Loesung.
    if model.status == GRB.OPTIMAL:
        print(f"\nOptimaler Zielfunktionswert: {model.ObjVal:.2f}\n")
        for j in N:
            for b in blocks:
                if (x[j,b].x > 0):
                    print(f"Variable {j} ist im Block {b} enthalten.")
            if (z[j].x > 0):
                print(f"Variable {j} ist linking.")
        for i in M:
            for b in blocks:
                if (y[i,b].x > 0):
                    print(f"Row {i} ist im Block {b} enthalten.")
    else:
        print(f"Keine Optimalloesung gefunden. Status {model.status}")
        
    return model