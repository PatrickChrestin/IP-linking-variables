import matplotlib.pyplot as plt
import numpy as np
from gurobipy import *
import staircasedetection_sparse 
from scipy.sparse import csr_matrix

def count_nonzero_entries_per_row(matrix):
    num_rows = matrix.shape[0]
    non_zero_counts = []
    for i in range(num_rows):
        row = matrix.getrow(i)
        non_zero_count = row.nnz
        non_zero_counts.append(non_zero_count)
    return non_zero_counts

vpm2 = gurobipy.read("vpm2/vpm2.mps")

# input coefficient matrix and parameters
A = vpm2.getA()
A_binary = csr_matrix((A.data != 0, A.indices, A.indptr), shape=A.shape)
# A_dense = A_binary.todense() 
# plt.imshow(A_dense, cmap='Greys')
# plt.savefig('A_blkwht.png')
# plt.show()

r_sum = count_nonzero_entries_per_row(A_binary)
N = range(1,A_binary.shape[1]+1)
M = range(1,A_binary.shape[0]+1)
k = 8
model = staircasedetection_sparse.solve(N, M, k, A_binary, r_sum)

model.write('staircasedetection.lp')
if model.Status == GRB.INFEASIBLE:
    model.computeIIS()
    model.write('iismodel.ilp')